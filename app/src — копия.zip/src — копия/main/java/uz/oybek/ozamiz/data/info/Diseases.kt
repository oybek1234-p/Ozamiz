package uz.oybek.ozamiz.data.info

enum class Problems(val text: String) {

    QANDLI_DIABET("Qandli diabet"),
    EMIZIKLI("Emizikli ayol"),
    HOMILADOR("Homilador ayol"),
    YURAK_QON_TOMIR("Yurak qon tomir kasalligi(Infarkt)")
}