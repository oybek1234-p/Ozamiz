package uz.oybek.ozamiz.data.info

object Gender {
    const val MALE = 0
    const val FEMALE = 1
}
